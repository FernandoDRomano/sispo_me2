<?php
class Popup extends CI_Controller{
    public function index(){
    $this->load->view("components/clientes/clientes/login.php");
    }    
}
?>